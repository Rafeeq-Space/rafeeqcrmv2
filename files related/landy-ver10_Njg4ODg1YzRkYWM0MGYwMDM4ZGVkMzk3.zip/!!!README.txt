Thank you for purchasing our product.
If you have any questions or difficulties, write to us and we will try to help you and we will do our best :)



---------------------- HOW TO COPY AND USE ---------------------- 


1. Register on FIGMA (www.figma.com)
2. Unzip the archive with the files
3. Open it using Figma (in the upper right corner the Import icon, then select the file and open it)
4. Templates will be added to your draft where you can correct them and modify them if you wish.
5. Thank you.

* The archive should have 1 files with all templates (Web Pages, Tablet Pages, Mobile Pages)



---------------------- FONTS ---------------------- 

For files to work properly, download and install fonts
(Should be available in figma by default)


Roboto Flex
https://fonts.google.com/specimen/Roboto+Flex

---------------------- IMAGES ---------------------- 

Images are not included in the product, you will have to replace them with your own or pick up images from free stock images, for example:
unsplash.com
picjumbo.com
kaboompics.com

---------------------- WHAT TO DO IF YOU CAN'T OPEN IT ---------------------- 

If you have any problems whit files, write to us in private messages or by e-mail: hello@welovegraphics.ru


------------------------------------------------------------------------------

We will be very grateful if you leave a good and positive feedback, this encourages us to make products better and more unique. 
Thank you:)